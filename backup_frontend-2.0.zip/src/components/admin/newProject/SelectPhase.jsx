import React from 'react'

export const SelectPhase = () => {
  return (
    <div>SelectPhase</div>
  )
}
